### Getting Started

1. **Create an App** - You will need to log in to your Dropbox account and [create a new app][].
2. **Set your app key/secret** - Replace the [placeholders][] in bootstrap.php with your new app key and secret.
3. **Run the examples** - You will now be able to run the examples provided!

[create a new app]: https://www.dropbox.com/developers/apps
[placeholders]: https://github.com/BenTheDesigner/Dropbox/blob/master/examples/bootstrap.php#L30-31