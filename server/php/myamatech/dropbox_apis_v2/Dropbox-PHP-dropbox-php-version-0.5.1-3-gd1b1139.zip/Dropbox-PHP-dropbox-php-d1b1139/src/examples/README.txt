The old examples have been removed.  Please see the unit tests under tests/ for more up-to-date example usage.
